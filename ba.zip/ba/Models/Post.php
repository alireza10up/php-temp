<?php

namespace Models;

class Post extends Model {

    public function user()
    {
        return User::where(['id', '=', $this->user_id])->first();
    }

    public function likes()
    {
        return Like::where(['post_id', '=', $this->id]);
    }

    public function isLikedBy($userId)
    {
        return $this->likes()->where(['user_id', '=', $userId])->count();
    }
}