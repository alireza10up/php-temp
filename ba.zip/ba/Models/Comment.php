<?php

namespace Models;

class Comment extends Model
{

}