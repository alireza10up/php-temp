<?php

namespace Models;

class Like extends Model
{
}