<?php

const __DATABASE_CONFIG__ = [
    'host' => 'localhost',
    'name' => 'instagram',
    'username' => 'root',
    'password' => '',
];