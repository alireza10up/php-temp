<?php
    require "../config/config.php";

    \Models\Like::create([
        'user_id' => $_POST['user_id'],
        'post_id' => $_POST['post_id'],
    ]);

    echo \Models\Like::where(['post_id', '=', $_POST['post_id']])->count();