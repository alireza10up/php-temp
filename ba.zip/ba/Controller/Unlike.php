<?php
require "../config/config.php";


    echo \Models\Like::where(['post_id', '=', $_POST['post_id']])->count();